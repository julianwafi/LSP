<div class="container mt-3">
	<?php if (isset($_SESSION['pesan'])) : ?>
		<?= $_SESSION['pesan'] ?>
	<?php unset($_SESSION['pesan']);
	endif; ?>
	<div class="card">
		<div class="card-header">
			Data User
		</div>
		<div class="card-body">
			<a href="index.php?registrasi"><button class="btn btn-primary btn-sm mb-3">Tambah Meja</button></a>
			<table class="table table-bordered table-hover table-striped" id="tabel">
				<thead>
					<tr>

						<th>ID meja</th>
						<th>Satatus</th>
						<?php if ($_SESSION['level'] == "Admin") : ?>
							<th>Aksi</th>
						<?php endif ?>
					</tr>
				</thead>
				<tbody>
					<!-- mengambil data dari database -->
					<?php
					$i = 1;
					$sql = mysqli_query($kon, "SELECT * FROM tb_meja");
					while ($data = mysqli_fetch_array($sql)) : ?>
						<tr>

							<td><?= $data['meja_id'] ?></td>
							<td><?= $data['status'] ?></td>
							<td>
								<div class="btn-group">
									<a href="fungsi/hapusUser.php?meja_id=<?= $data['meja_id']; ?>" class="btn btn-danger btn-sm">Hapus</a>
								</div>
							</td>

						</tr>
					<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>